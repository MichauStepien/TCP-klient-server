﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCP_Server //uruchomić jako piwerszy, potem klienta
{
    public partial class Form1 : Form
    {
        //IPAddress ip; //192.168.1.5
        TcpListener server = null;
        TcpClient client = null;
        int wcisk = 1;
        public volatile bool listening;
        String ip;
        volatile bool bloker = false;
        Thread thr;
        //object cancellation;
        CancellationTokenSource cancellation = new CancellationTokenSource();
        public Form1()
        {
            InitializeComponent();
        }

        private void button_start_Click(object sender, EventArgs e)
        {

                bloker = false;
                parse(textBox1.Text);
                if (bloker == true)
                   {
                     ip = textBox1.Text;
                   }
                else
                  {
                     ip = "127.0.0.1";
                      MessageBox.Show("Adres IP domyślny");
                  }
            if (wcisk == 1)
             {
                 listening = true;
                 thr = new Thread(new ThreadStart(Maine));
                 thr.Start();
                 wcisk = 0;
                 this.ControlBox = false; // zablokuj wyłaczenie programu, zamknięcie aplikacji bez zakończenia wątku spowoduje jego prace w tle
             }
             else
             {
                this.ControlBox = true;
                listening = false;
                cancellation.Cancel();
                //cancellation.Dispose();
                //thr.Join();
               try
                {
                    client.Close();
                    server.Stop();               
                 }
               catch { }
                thr.Join();
                wcisk = 1;            
             }
             
           //listening = true;
         // thr = new Thread(new ThreadStart(Main));
          // thr.Start();
            
        }

        public void Main()
        {
            try
            {
                // Set the TcpListener on port 13000.
                Int32 port = 13000;
                IPAddress localAddr = IPAddress.Parse(ip);

                // TcpListener server = new TcpListener(port);
                server = new TcpListener(localAddr, port);

                // Start listening for client requests.
                server.Start();

                // Buffer for reading data
                Byte[] bytes = new Byte[256];
                String data = null;

                // Enter the listening loop.
                while (listening)
                {      
                    richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Waiting for a connection... " ); }));
                    // Perform a blocking call to accept requests.
                    // You could also user server.AcceptSocket() here.
                    client = server.AcceptTcpClient();
                    //Console.WriteLine("Connected!");
                    richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Connected!"); }));
                    data = null;

                    // Get a stream object for reading and writing
                    NetworkStream stream = client.GetStream();

                    int i;

                    // Loop to receive all the data sent by the client.
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        // Translate data bytes to a ASCII string.
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);                       
                        richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Received: {0}" + data); }));
                        // Process the data sent by the client.
                        data = data.ToUpper();

                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);

                        // Send back a response.
                        stream.Write(msg, 0, msg.Length);
                        richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Sent: {0}" + data); }));
                    }

                    // Shutdown and end connection
                    client.Close();
                }
            }

             catch (Exception e)
                {
                listening = false;
                MessageBox.Show(e.Message);
                //server.Stop();
                //return;
            }
            /*catch (SocketException e)
            {
                //Console.WriteLine("SocketException: {0}", e);
                MessageBox.Show(e.Message);
            }*/
            finally
            {
                richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Finish"); }));
                // Stop listening for new clients.
                server.Stop();
            }
          
        }

        public async void Maine()
        {
            server = null;
            client = null;
            try
            {
                // Set the TcpListener on port 13000.
                Int32 port = 13000;
                IPAddress localAddr = IPAddress.Parse(ip);

                // TcpListener server = new TcpListener(port);
                server = new TcpListener(localAddr, port);
                server.Start();             

                // Buffer for reading data
                Byte[] bytes = new Byte[256];
                String data = null;
               // var cancellation = new CancellationTokenSource();

                // Enter the listening loop.
                while (listening)
                {
                    richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Waiting for a connection... "); }));
                    // Perform a blocking call to accept requests.
                    // You could also user server.AcceptSocket() here.
                    client = await Task.Run(() => server.AcceptTcpClientAsync(),cancellation.Token);
                   
                    //Mozna dać try catch


                    richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Connected!"); }));
                    data = null;
             
                    NetworkStream stream = client.GetStream();

                    int i;             
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        // Translate data bytes to a ASCII string.
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                        richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Received: {0}" + data); }));
                        // Process the data sent by the client.
                        data = data.ToUpper();

                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);

                        // Send back a response.
                        stream.Write(msg, 0, msg.Length);
                        richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Sent: {0}" + data); }));
                    }
                    client.Close();
                }
            }

            catch (SocketException e)
            {
                listening = false;
                MessageBox.Show(e.Message);
                //server.Stop();
                //return;
            }
            /*catch (SocketException e)
            {
                //Console.WriteLine("SocketException: {0}", e);
                MessageBox.Show(e.Message);
            }*/
            finally
            {
                richTextBox1.Invoke(new Action(delegate () { richTextBox1.AppendText("Finish"); }));
                // Stop listening for new clients.
                server.Stop();
            }

        }



        private void parse(string ipAddress)
        {
            try
            {
                IPAddress.Parse(ipAddress);
                bloker = true;
            }

            catch (ArgumentNullException e)
            {
                MessageBox.Show("Source ANE: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }
            catch (FormatException e)
            {
                MessageBox.Show("Source FE: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }

            catch (Exception e)
            {
                MessageBox.Show("Source E: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }
        }


        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

