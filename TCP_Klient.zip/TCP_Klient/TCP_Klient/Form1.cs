﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCP_Klient // uruchomić jako druga, pierwszy serwer
{
    public partial class Form1 : Form
    {

        //string ipAdres = "192.168.1.5";
        string ipAdres = "127.0.0.1";
        // IPAddress ipAdres = IPAddress.Parse("172.21.5.99");
        string message = "hej";
        volatile bool bloker = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_start_Click(object sender, EventArgs e)
        {
            message = textBox1.Text;
            if (textBox1.Text == "")
            { message = "brak wiadomosci"; }

            ipAdres = textBox2.Text;
            if (textBox2.Text == "")
            { ipAdres= "127.0.0.1"; }

            Connect(ipAdres,message);
        }

         void Connect(String server, String message)
        {
            try
            {
                // Create a TcpClient.
                // Note, for this client to work you need to have a TcpServer 
                // connected to the same address as specified by the server, port
                // combination.
                Int32 port = 13000;
                TcpClient client = new TcpClient(server, port);

                // Translate the passed message into ASCII and store it as a Byte array.
                Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

                // Get a client stream for reading and writing.
                //  Stream stream = client.GetStream();

                NetworkStream stream = client.GetStream();

                // Send the message to the connected TcpServer. 
                stream.Write(data, 0, data.Length);

               //Console.WriteLine("Sent: {0}",message);
                richTextBox1.AppendText("Sent: {0}" + message);

                // Receive the TcpServer.response.

                // Buffer to store the response bytes.
                data = new Byte[256];

                // String to store the response ASCII representation.
                String responseData = String.Empty;

                // Read the first batch of the TcpServer response bytes.
                Int32 bytes = stream.Read(data, 0, data.Length);
                responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
 //Console.WriteLine("Received: {0}", responseData);
                richTextBox1.AppendText("Received: {0}" + responseData);
                // Close everything.
                stream.Close();
                client.Close();
            }
            catch (ArgumentNullException e)
            {
                //Console.WriteLine("ArgumentNullException: {0}", e);
                MessageBox.Show(e.Message);
            }
            catch (SocketException e)
            {
                // Console.WriteLine("SocketException: {0}", e);
                MessageBox.Show(e.Message);
            }
            richTextBox1.AppendText("Finish");
            //Console.WriteLine("\n Press Enter to continue...");
            //Console.Read();
        }

        private void parse(string ipAddress)
        {
            try
            {
                IPAddress.Parse(ipAddress);
                bloker = true;
            }

            catch (ArgumentNullException e)
            {
                MessageBox.Show("Source ANE: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }
            catch (FormatException e)
            {
                MessageBox.Show("Source FE: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }

            catch (Exception e)
            {
                MessageBox.Show("Source E: " + e.Source);
                MessageBox.Show("Message : " + e.Message);
            }
        }


        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
